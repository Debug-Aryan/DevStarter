package com.devstarter.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevStarterApplication.class, args);
	}

}
