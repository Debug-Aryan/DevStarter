const mongoose = require('mongoose');
const logger = require('./logger');

const connectDB = async () => {
    if (!process.env.MONGO_URI) {
        logger.info('Mongo URI not found, skipping DB connection');
        return;
    }
    try {
        const conn = await mongoose.connect(process.env.MONGO_URI);
        logger.info(`MongoDB Connected: ${conn.connection.host}`);
    } catch (error) {
        logger.error(`Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = { connectDB };
