# test-django-no-readme

desc

## Stack
- Python 3.12+
- Django 5
